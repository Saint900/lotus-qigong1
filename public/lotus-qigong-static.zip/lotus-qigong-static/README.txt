Lotus Moving QiGong - 静态网站部署指南
=========================================

一、文件结构说明
---------------
lotus-qigong-static/
├── index.html              # 网站入口
├── favicon.svg             # 网站图标
├── icons.svg               # 图标集
├── routes.json             # 路由配置
├── README.txt              # 本文件
├── assets/                 # JS/CSS 资源
│   ├── index-*.js          # 主应用 JS
│   ├── index-*.css         # 样式文件
│   ├── polyfills.js        # 兼容补丁
│   ├── radix-*.js          # UI 组件库
│   ├── toolkit-*.js        # 工具库
│   └── rolldown-runtime-*.js
└── images/                 # 图片资源
    ├── hero-bg.jpg         # 首页 Hero 背景图
    ├── master.jpg          # 大师介绍图
    ├── course-1.jpg        # 课程封面 1
    ├── course-2.jpg        # 课程封面 2
    └── course-3.jpg        # 课程封面 3

二、上传到 VPS
--------------
方式一：FTP/SFTP
  1. 用 FileZilla 等 FTP 工具连接你的 VPS
  2. 将本目录下所有文件上传到网站根目录
     （通常是 /var/www/html/ 或 /usr/share/nginx/html/）
  3. 确保文件权限正确（一般 644 即可）

方式二：SCP 命令行
  scp -r ./lotus-qigong-static/* user@your-server:/var/www/html/

方式三：rsync（推荐，增量同步）
  rsync -avz ./lotus-qigong-static/ user@your-server:/var/www/html/

三、Nginx 配置（SPA 路由回退）
-------------------------------
本网站是单页应用（SPA），所有路由由前端处理。
直接访问子路径（如 /courses、/about）会返回 404，
需要在 Nginx 中配置 try_files 将所有请求回退到 index.html。

示例配置 /etc/nginx/conf.d/lotus-qigong.conf：

  server {
      listen 80;
      server_name your-domain.com;
      root /var/www/html;
      index index.html;

      # gzip 压缩（可选，推荐开启）
      gzip on;
      gzip_types text/plain text/css application/javascript image/svg+xml;
      gzip_min_length 1024;

      # SPA 路由回退：找不到文件时返回 index.html
      location / {
          try_files $uri $uri/ /index.html;
      }

      # 静态资源缓存（可选，提升性能）
      location ~* \.(jpg|jpeg|png|gif|ico|svg|css|js)$ {
          expires 30d;
          add_header Cache-Control "public, immutable";
      }
  }

修改后重启 Nginx：
  sudo nginx -t && sudo systemctl restart nginx

四、注意事项
------------
1. 本静态包使用相对路径（./assets/...、./images/...），
   可以部署在网站根目录或任意子目录下。
   但 SPA 路由需要服务器正确配置 try_files。

2. 如果部署在子目录（如 https://your-domain.com/qigong/），
   需要同时调整 Nginx 的 root 和 try_files 路径。

3. 首次上传后请清除浏览器缓存再访问，避免旧版缓存影响。

4. 网站所有资源都是静态文件，无需 Node.js、无需后端服务。
